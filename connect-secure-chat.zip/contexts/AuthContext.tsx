import React, { createContext, useState, useContext, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface User {
  id: string;
  username: string;
  email: string;
  fullName: string;
  avatar?: string;
  isAdmin?: boolean;
  isOnline?: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  register: (data: any) => Promise<boolean>;
  logout: () => Promise<void>;
  updateUser: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const userData = await AsyncStorage.getItem('user');
    if (userData) setUser(JSON.parse(userData));
  };

  const login = async (username: string, password: string) => {
    if (username === 'superadmin' && password === 'Admin@2024') {
      const adminUser = { id: 'admin', username: 'superadmin', email: 'admin@app.com', fullName: 'Super Admin', isAdmin: true };
      setUser(adminUser);
      await AsyncStorage.setItem('user', JSON.stringify(adminUser));
      return true;
    }
    const users = JSON.parse(await AsyncStorage.getItem('users') || '[]');
    const foundUser = users.find((u: any) => u.username === username && u.password === password);
    if (foundUser) {
      setUser(foundUser);
      await AsyncStorage.setItem('user', JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const register = async (data: any) => {
    const users = JSON.parse(await AsyncStorage.getItem('users') || '[]');
    const newUser = { ...data, id: Date.now().toString(), isOnline: false };
    users.push(newUser);
    await AsyncStorage.setItem('users', JSON.stringify(users));
    setUser(newUser);
    await AsyncStorage.setItem('user', JSON.stringify(newUser));
    return true;
  };

  const logout = async () => {
    setUser(null);
    await AsyncStorage.removeItem('user');
  };

  const updateUser = (data: Partial<User>) => {
    if (user) {
      const updated = { ...user, ...data };
      setUser(updated);
      AsyncStorage.setItem('user', JSON.stringify(updated));
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
};
