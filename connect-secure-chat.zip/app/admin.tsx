import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../contexts/AuthContext';
import { useRouter } from 'expo-router';

export default function Admin() {
  const [users, setUsers] = useState([]);
  const { logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const usersData = await AsyncStorage.getItem('users');
    if (usersData) {
      setUsers(JSON.parse(usersData));
    }
  };

  const handleLogout = async () => {
    await logout();
    router.replace('/');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Admin Panel</Text>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Text style={styles.logoutText}>Chiqish</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.subtitle}>Ro'yxatdan o'tgan foydalanuvchilar: {users.length}</Text>

      <FlatList
        data={users}
        keyExtractor={(item: any) => item.id}
        renderItem={({ item }: any) => (
          <View style={styles.userCard}>
            <Image 
              source={{ uri: item.avatar || 'https://d64gsuwffb70l.cloudfront.net/690b7c0a27740c7e2521ae17_1762360383093_6a282380.webp' }}
              style={styles.avatar}
            />
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{item.fullName}</Text>
              <Text style={styles.userEmail}>{item.email}</Text>
              <Text style={styles.userUsername}>@{item.username}</Text>
            </View>
            <View style={[styles.statusDot, { backgroundColor: item.isOnline ? '#4CAF50' : '#999' }]} />
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#2196F3', padding: 20, paddingTop: 50, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', color: '#fff' },
  logoutBtn: { backgroundColor: 'rgba(255,255,255,0.2)', padding: 8, borderRadius: 8 },
  logoutText: { color: '#fff', fontWeight: '600' },
  subtitle: { padding: 16, fontSize: 16, fontWeight: '600', color: '#333' },
  userCard: { backgroundColor: '#fff', padding: 16, marginHorizontal: 16, marginBottom: 12, borderRadius: 12, flexDirection: 'row', alignItems: 'center', elevation: 2 },
  avatar: { width: 50, height: 50, borderRadius: 25, marginRight: 12 },
  userInfo: { flex: 1 },
  userName: { fontSize: 16, fontWeight: '600', color: '#333' },
  userEmail: { fontSize: 14, color: '#666', marginTop: 2 },
  userUsername: { fontSize: 12, color: '#999', marginTop: 2 },
  statusDot: { width: 12, height: 12, borderRadius: 6 },
});
