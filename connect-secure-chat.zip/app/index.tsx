import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../contexts/AuthContext';

export default function Index() {
  const router = useRouter();
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      if (user.isAdmin) {
        router.replace('/admin');
      } else {
        router.replace('/chats');
      }
    }
  }, [user]);

  return (
    <View style={styles.container}>
      <Image 
        source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/690b7c0a27740c7e2521ae17_1762360382312_343375d0.webp' }}
        style={styles.logo}
      />
      <Text style={styles.title}>Messenger</Text>
      <Text style={styles.subtitle}>Xavfsiz va tez xabar almashish</Text>
      
      <TouchableOpacity style={styles.button} onPress={() => router.push('/login')}>
        <Text style={styles.buttonText}>Kirish</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={styles.buttonOutline} onPress={() => router.push('/register')}>
        <Text style={styles.buttonOutlineText}>Ro'yxatdan o'tish</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff', padding: 20 },
  logo: { width: 120, height: 120, marginBottom: 20, borderRadius: 60 },
  title: { fontSize: 32, fontWeight: 'bold', color: '#2196F3', marginBottom: 10 },
  subtitle: { fontSize: 16, color: '#666', marginBottom: 40 },
  button: { width: '100%', backgroundColor: '#2196F3', padding: 16, borderRadius: 12, marginBottom: 12 },
  buttonText: { color: '#fff', textAlign: 'center', fontSize: 16, fontWeight: '600' },
  buttonOutline: { width: '100%', borderWidth: 2, borderColor: '#2196F3', padding: 16, borderRadius: 12 },
  buttonOutlineText: { color: '#2196F3', textAlign: 'center', fontSize: 16, fontWeight: '600' },
});
