import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../contexts/AuthContext';

export default function Register() {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    fullName: '',
    password: '',
    confirmPassword: '',
  });
  const router = useRouter();
  const { register } = useAuth();

  const handleRegister = async () => {
    if (!formData.username || !formData.email || !formData.fullName || !formData.password) {
      Alert.alert('Xato', 'Iltimos barcha maydonlarni to\'ldiring');
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      Alert.alert('Xato', 'Parollar mos kelmaydi');
      return;
    }

    await register(formData);
    Alert.alert('Muvaffaqiyat', 'Ro\'yxatdan o\'tdingiz!');
    router.replace('/chats');
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Ro'yxatdan o'tish</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Foydalanuvchi nomi"
        value={formData.username}
        onChangeText={(text) => setFormData({...formData, username: text})}
        autoCapitalize="none"
      />
      
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={formData.email}
        onChangeText={(text) => setFormData({...formData, email: text})}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      
      <TextInput
        style={styles.input}
        placeholder="To'liq ism"
        value={formData.fullName}
        onChangeText={(text) => setFormData({...formData, fullName: text})}
      />
      
      <TextInput
        style={styles.input}
        placeholder="Parol"
        value={formData.password}
        onChangeText={(text) => setFormData({...formData, password: text})}
        secureTextEntry
      />
      
      <TextInput
        style={styles.input}
        placeholder="Parolni tasdiqlang"
        value={formData.confirmPassword}
        onChangeText={(text) => setFormData({...formData, confirmPassword: text})}
        secureTextEntry
      />
      
      <TouchableOpacity style={styles.button} onPress={handleRegister}>
        <Text style={styles.buttonText}>Ro'yxatdan o'tish</Text>
      </TouchableOpacity>
      
      <TouchableOpacity onPress={() => router.push('/login')}>
        <Text style={styles.link}>Akkauntingiz bormi? Kirish</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 28, fontWeight: 'bold', marginTop: 40, marginBottom: 30, textAlign: 'center', color: '#2196F3' },
  input: { borderWidth: 1, borderColor: '#ddd', padding: 14, borderRadius: 10, marginBottom: 16, fontSize: 16 },
  button: { backgroundColor: '#2196F3', padding: 16, borderRadius: 10, marginTop: 10 },
  buttonText: { color: '#fff', textAlign: 'center', fontSize: 16, fontWeight: '600' },
  link: { color: '#2196F3', textAlign: 'center', marginTop: 20, marginBottom: 40, fontSize: 16 },
});
