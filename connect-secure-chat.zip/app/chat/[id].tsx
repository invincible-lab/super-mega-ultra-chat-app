import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../contexts/AuthContext';

export default function ChatScreen() {
  const { id } = useLocalSearchParams();
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [otherUser, setOtherUser] = useState<any>(null);
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    loadChatData();
  }, []);

  const loadChatData = async () => {
    const usersData = await AsyncStorage.getItem('users');
    if (usersData) {
      const users = JSON.parse(usersData);
      const found = users.find((u: any) => u.id === id);
      setOtherUser(found);
    }

    const chatKey = [user?.id, id].sort().join('_');
    const messagesData = await AsyncStorage.getItem(`chat_${chatKey}`);
    if (messagesData) {
      setMessages(JSON.parse(messagesData));
    }
  };

  const sendMessage = async () => {
    if (!inputText.trim()) return;

    const newMessage = {
      id: Date.now().toString(),
      text: inputText,
      senderId: user?.id,
      timestamp: new Date().toISOString(),
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);

    const chatKey = [user?.id, id].sort().join('_');
    await AsyncStorage.setItem(`chat_${chatKey}`, JSON.stringify(updatedMessages));
    setInputText('');
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.backBtn}>←</Text>
        </TouchableOpacity>
        <Image 
          source={{ uri: otherUser?.avatar || 'https://d64gsuwffb70l.cloudfront.net/690b7c0a27740c7e2521ae17_1762360386550_96491e19.webp' }}
          style={styles.avatar}
        />
        <View style={styles.headerInfo}>
          <Text style={styles.headerTitle}>{otherUser?.fullName}</Text>
          <Text style={styles.headerStatus}>{otherUser?.isOnline ? 'Online' : 'Offline'}</Text>
        </View>
      </View>

      <FlatList
        data={messages}
        keyExtractor={(item: any) => item.id}
        style={styles.messagesList}
        renderItem={({ item }: any) => {
          const isMyMessage = item.senderId === user?.id;
          return (
            <View style={[styles.messageBubble, isMyMessage ? styles.myMessage : styles.theirMessage]}>
              <Text style={[styles.messageText, { color: isMyMessage ? '#fff' : '#333' }]}>{item.text}</Text>
              <Text style={[styles.messageTime, { color: isMyMessage ? 'rgba(255,255,255,0.8)' : '#999' }]}>
                {new Date(item.timestamp).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </View>
          );
        }}
      />

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Xabar yozing..."
          value={inputText}
          onChangeText={setInputText}
          multiline
        />
        <TouchableOpacity style={styles.sendBtn} onPress={sendMessage}>
          <Text style={styles.sendBtnText}>➤</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#2196F3', padding: 16, paddingTop: 50, flexDirection: 'row', alignItems: 'center' },
  backBtn: { fontSize: 28, color: '#fff', marginRight: 12 },
  avatar: { width: 40, height: 40, borderRadius: 20, marginRight: 12 },
  headerInfo: { flex: 1 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: '#fff' },
  headerStatus: { fontSize: 12, color: 'rgba(255,255,255,0.8)' },
  messagesList: { flex: 1, padding: 16 },
  messageBubble: { maxWidth: '75%', padding: 12, borderRadius: 16, marginBottom: 8 },
  myMessage: { alignSelf: 'flex-end', backgroundColor: '#2196F3' },
  theirMessage: { alignSelf: 'flex-start', backgroundColor: '#fff' },
  messageText: { fontSize: 16 },
  messageTime: { fontSize: 10, marginTop: 4, textAlign: 'right' },
  inputContainer: { flexDirection: 'row', padding: 12, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#ddd' },
  input: { flex: 1, backgroundColor: '#f5f5f5', padding: 12, borderRadius: 20, fontSize: 16, maxHeight: 100 },
  sendBtn: { width: 44, height: 44, backgroundColor: '#2196F3', borderRadius: 22, justifyContent: 'center', alignItems: 'center', marginLeft: 8 },
  sendBtnText: { fontSize: 20, color: '#fff' },
});
