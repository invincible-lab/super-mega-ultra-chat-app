import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ScrollView, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../contexts/AuthContext';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [email, setEmail] = useState(user?.email || '');
  const router = useRouter();

  const handleSave = () => {
    updateUser({ fullName, email });
    Alert.alert('Muvaffaqiyat', 'Profil yangilandi!');
    router.back();
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.backBtn}>←</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Profil</Text>
      </View>

      <View style={styles.avatarContainer}>
        <Image 
          source={{ uri: user?.avatar || 'https://d64gsuwffb70l.cloudfront.net/690b7c0a27740c7e2521ae17_1762360388296_d45418e2.webp' }}
          style={styles.avatar}
        />
        <TouchableOpacity style={styles.changeAvatarBtn}>
          <Text style={styles.changeAvatarText}>Rasmni o'zgartirish</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.form}>
        <Text style={styles.label}>To'liq ism</Text>
        <TextInput
          style={styles.input}
          value={fullName}
          onChangeText={setFullName}
        />

        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />

        <Text style={styles.label}>Foydalanuvchi nomi</Text>
        <TextInput
          style={[styles.input, styles.disabledInput]}
          value={user?.username}
          editable={false}
        />

        <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
          <Text style={styles.saveBtnText}>Saqlash</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#2196F3', padding: 20, paddingTop: 50, flexDirection: 'row', alignItems: 'center' },
  backBtn: { fontSize: 28, color: '#fff', marginRight: 16 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#fff' },
  avatarContainer: { alignItems: 'center', paddingVertical: 30, backgroundColor: '#fff' },
  avatar: { width: 120, height: 120, borderRadius: 60, marginBottom: 16 },
  changeAvatarBtn: { padding: 8 },
  changeAvatarText: { color: '#2196F3', fontSize: 16 },
  form: { padding: 20 },
  label: { fontSize: 14, fontWeight: '600', color: '#666', marginBottom: 8, marginTop: 12 },
  input: { backgroundColor: '#fff', padding: 14, borderRadius: 10, fontSize: 16, borderWidth: 1, borderColor: '#ddd' },
  disabledInput: { backgroundColor: '#f5f5f5', color: '#999' },
  saveBtn: { backgroundColor: '#2196F3', padding: 16, borderRadius: 10, marginTop: 30 },
  saveBtnText: { color: '#fff', textAlign: 'center', fontSize: 16, fontWeight: '600' },
});
