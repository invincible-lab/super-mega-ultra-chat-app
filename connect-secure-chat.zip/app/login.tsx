import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../contexts/AuthContext';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();
  const { login } = useAuth();

  const handleLogin = async () => {
    if (!username || !password) {
      Alert.alert('Xato', 'Iltimos barcha maydonlarni to\'ldiring');
      return;
    }

    const success = await login(username, password);
    if (success) {
      if (username === 'superadmin') {
        router.replace('/admin');
      } else {
        router.replace('/chats');
      }
    } else {
      Alert.alert('Xato', 'Login yoki parol noto\'g\'ri');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Kirish</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Foydalanuvchi nomi"
        value={username}
        onChangeText={setUsername}
        autoCapitalize="none"
      />
      
      <TextInput
        style={styles.input}
        placeholder="Parol"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Kirish</Text>
      </TouchableOpacity>
      
      <TouchableOpacity onPress={() => router.push('/register')}>
        <Text style={styles.link}>Ro'yxatdan o'tish</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff', justifyContent: 'center' },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 30, textAlign: 'center', color: '#2196F3' },
  input: { borderWidth: 1, borderColor: '#ddd', padding: 14, borderRadius: 10, marginBottom: 16, fontSize: 16 },
  button: { backgroundColor: '#2196F3', padding: 16, borderRadius: 10, marginTop: 10 },
  buttonText: { color: '#fff', textAlign: 'center', fontSize: 16, fontWeight: '600' },
  link: { color: '#2196F3', textAlign: 'center', marginTop: 20, fontSize: 16 },
});
