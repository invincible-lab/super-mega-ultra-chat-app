import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image, TextInput } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../contexts/AuthContext';
import { useRouter } from 'expo-router';

export default function Chats() {
  const [users, setUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const { user, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const usersData = await AsyncStorage.getItem('users');
    if (usersData) {
      const allUsers = JSON.parse(usersData);
      setUsers(allUsers.filter((u: any) => u.id !== user?.id));
    }
  };

  const filteredUsers = users.filter((u: any) => 
    u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleLogout = async () => {
    await logout();
    router.replace('/');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Chatlar</Text>
          <Text style={styles.subtitle}>{user?.fullName}</Text>
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity onPress={() => router.push('/profile')} style={styles.iconBtn}>
            <Text style={styles.iconText}>👤</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleLogout} style={styles.iconBtn}>
            <Text style={styles.iconText}>🚪</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Qidirish..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <FlatList
        data={filteredUsers}
        keyExtractor={(item: any) => item.id}
        renderItem={({ item }: any) => (
          <TouchableOpacity 
            style={styles.chatCard}
            onPress={() => router.push(`/chat/${item.id}`)}
          >
            <Image 
              source={{ uri: item.avatar || 'https://d64gsuwffb70l.cloudfront.net/690b7c0a27740c7e2521ae17_1762360384815_5861cf5d.webp' }}
              style={styles.avatar}
            />
            <View style={styles.chatInfo}>
              <Text style={styles.chatName}>{item.fullName}</Text>
              <Text style={styles.chatUsername}>@{item.username}</Text>
            </View>
            <View style={[styles.statusDot, { backgroundColor: item.isOnline ? '#4CAF50' : '#999' }]} />
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#2196F3', padding: 20, paddingTop: 50, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', color: '#fff' },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginTop: 2 },
  headerRight: { flexDirection: 'row' },
  iconBtn: { marginLeft: 12 },
  iconText: { fontSize: 24 },
  searchContainer: { padding: 16 },
  searchInput: { backgroundColor: '#fff', padding: 12, borderRadius: 10, fontSize: 16 },
  chatCard: { backgroundColor: '#fff', padding: 16, marginHorizontal: 16, marginBottom: 8, borderRadius: 12, flexDirection: 'row', alignItems: 'center' },
  avatar: { width: 50, height: 50, borderRadius: 25, marginRight: 12 },
  chatInfo: { flex: 1 },
  chatName: { fontSize: 16, fontWeight: '600', color: '#333' },
  chatUsername: { fontSize: 14, color: '#666', marginTop: 2 },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
});
