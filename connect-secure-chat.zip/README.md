# Telegram-style Messenger App

Zamonaviy messenger ilovasi - React Native va Expo bilan yaratilgan.

## Xususiyatlar

✅ **Superadmin Panel**: Barcha foydalanuvchilarni ko'rish va boshqarish
- Login: `superadmin`
- Parol: `Admin@2024`

✅ **Foydalanuvchi Ro'yxatdan O'tish**: To'liq registratsiya tizimi
✅ **Real-time Messaging**: Ikki foydalanuvchi o'rtasida xabar almashish
✅ **Foydalanuvchilar Ro'yxati**: Barcha aktiv foydalanuvchilar
✅ **Qidiruv Funksiyasi**: Foydalanuvchilarni qidirish
✅ **Profil Boshqaruvi**: Shaxsiy ma'lumotlarni tahrirlash
✅ **Online Status**: Foydalanuvchi holati ko'rsatiladi

## O'rnatish

```bash
npm install
```

## Ishga Tushirish

```bash
# Development rejimida
npm start

# Android qurilmada
npm run android

# iOS qurilmada
npm run ios
```

## APK Yaratish

```bash
# EAS Build bilan (tavsiya etiladi)
npx eas build --platform android --profile preview

# Yoki local build
npx expo prebuild
cd android && ./gradlew assembleRelease
```

## Foydalanish

1. Ilovani oching
2. "Ro'yxatdan o'tish" tugmasini bosing
3. Ma'lumotlaringizni kiriting
4. Boshqa foydalanuvchilar bilan chat boshlang!

## Superadmin Kirish

- Username: `superadmin`
- Password: `Admin@2024`

Admin panel orqali barcha ro'yxatdan o'tgan foydalanuvchilarni ko'rishingiz mumkin.

## Texnologiyalar

- React Native
- Expo Router
- AsyncStorage
- TypeScript
