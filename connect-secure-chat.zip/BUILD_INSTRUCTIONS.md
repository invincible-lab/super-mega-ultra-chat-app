# APK Yaratish Bo'yicha Qo'llanma

## Usul 1: EAS Build (Tavsiya etiladi - Eng Oson)

EAS Build - Expo ning cloud build xizmati. Bu eng oson va ishonchli usul.

### 1. EAS CLI o'rnatish
```bash
npm install -g eas-cli
```

### 2. Expo akkauntiga kirish
```bash
eas login
```

### 3. Loyihani sozlash
```bash
eas build:configure
```

### 4. APK yaratish
```bash
eas build --platform android --profile preview
```

Build jarayoni 10-20 daqiqa davom etadi. Tugagach, APK faylini yuklab olish uchun link beriladi.

---

## Usul 2: Local Build (Murakkab)

Agar local kompyuteringizda build qilmoqchi bo'lsangiz:

### Talablar:
- Android Studio
- Java Development Kit (JDK)
- Android SDK

### Qadamlar:

1. **Prebuild qilish:**
```bash
npx expo prebuild --platform android
```

2. **Android papkasiga o'tish:**
```bash
cd android
```

3. **APK yaratish:**
```bash
./gradlew assembleRelease
```

4. **APK joylashuvi:**
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## Usul 3: Expo Go (Test uchun)

Development jarayonida test qilish uchun:

1. **Expo Go ilovasini o'rnating** (Play Store dan)
2. **Loyihani ishga tushiring:**
```bash
npm start
```
3. **QR kodni skanerlang** Expo Go ilovasi orqali

---

## Muhim Eslatmalar

- **EAS Build** eng oson va professional usul
- **Local Build** uchun Android development muhiti kerak
- **Expo Go** faqat development uchun, production APK emas

## Qo'shimcha Yordam

Agar muammolar bo'lsa:
- Expo dokumentatsiyasi: https://docs.expo.dev/build/setup/
- EAS Build qo'llanma: https://docs.expo.dev/build/introduction/
